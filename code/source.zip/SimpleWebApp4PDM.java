package arm.isg.jp.ws.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleWebApp4PDM {

    public static void main(String[] args) {
        SpringApplication.run(SimpleWebApp4PDM.class, args);
    }

}