package arm.isg.jp.ws.web;

import com.arm.mbed.cloud.Sdk;
import com.arm.mbed.cloud.sdk.common.ConnectionOptions;
import com.arm.mbed.cloud.sdk.common.TimePeriod;
import com.arm.mbed.cloud.sdk.common.listing.Paginator;
import com.arm.mbed.cloud.sdk.connect.model.Resource;
import com.arm.mbed.cloud.sdk.devices.model.Device;
import com.arm.mbed.cloud.sdk.devices.model.DeviceListDao;
import com.arm.mbed.cloud.sdk.devices.model.DeviceListOptions;
import com.arm.mbed.cloud.sdk.devices.model.DeviceState;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.MediaType;

import java.util.List;
import java.util.ArrayList;

@RestController
public class SimpleWebApp4PDMController {

    @RequestMapping("api/devices/registered")
    public List<Device> showRegisteredDevices() {

        List<Device> deviceList = new ArrayList<Device>();

        try {
            Sdk sdk = Sdk.createSdk(ConnectionOptions.newConfiguration());
            sdk.foundation().getDeviceListDao()
                    .list((new DeviceListOptions()).equalToState(DeviceState.REGISTERED).maxResults(10))
                    .forEach(device -> deviceList.add(device));
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return deviceList;
    }

    @RequestMapping(value = "/api/devices/deregistered", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Device> listDeregistered() {

        List<Device> deviceList = new ArrayList<Device>();

        try {
            Sdk sdk = Sdk.createSdk(ConnectionOptions.newConfiguration());
            sdk.foundation().getDeviceListDao()
                    .list((new DeviceListOptions()).equalToState(DeviceState.DEREGISTERED).maxResults(10))
                    .forEach(device -> deviceList.add(device));
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return deviceList;
    }


    @RequestMapping(value = "/api/devices/all")
    public List<Device> index() {

        List<Device> deviceList = new ArrayList<Device>();

        try {
            Sdk sdk = Sdk.createSdk(ConnectionOptions.newConfiguration());
            sdk.foundation().getDeviceListDao().list((new DeviceListOptions()).maxResults(10)).forEach(device -> deviceList.add(device));
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return deviceList;

    }

    @RequestMapping(value = "/api/devices/sample/resources", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String getResourcesSample() {

        Object value;
        String responseData = null;

        try (Sdk sdk = Sdk.createSdk(ConnectionOptions.newConfiguration()); DeviceListDao dao = sdk.foundation().getDeviceListDao()) {

            Paginator<Device> deviceIterator = dao.list(new DeviceListOptions().equalToState(DeviceState.REGISTERED)
                    .maxResults(1));
            Device device = deviceIterator.first();

            List<Resource> observableResources = sdk.lowLevelRest().getConnectModule().listObservableResources(device);

            System.out.println("Device " + device.getId() + " has following resources: ");

            for (int i = 0; i <= 25; i++) {
                Resource resource = observableResources.get(i);
                value = sdk.lowLevelRest().getConnectModule().getResourceValue(resource, new TimePeriod(10));
                System.out.println("Path " + resource.getPath() + ", current value: "
                        + value);
                if (i == 21) {
                    responseData = value.toString();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return new String("Digital Input - Digital Input Counter \"/3200/0/5501\" : " + responseData);
    }

    @RequestMapping(value = "/api/devices/sample/buttonCount", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String getButtonCount() {

        Object value;
        String responseData = null;

        try (Sdk sdk = Sdk.createSdk(ConnectionOptions.newConfiguration()); DeviceListDao dao = sdk.foundation().getDeviceListDao()) {

            Paginator<Device> deviceIterator = dao.list(new DeviceListOptions().equalToState(DeviceState.REGISTERED)
                    .maxResults(1));
            Device device = deviceIterator.first();

            List<Resource> observableResources = sdk.lowLevelRest().getConnectModule().listObservableResources(device);

            Resource resource = observableResources.get(21);
            responseData = sdk.lowLevelRest().getConnectModule().getResourceValue(resource, new TimePeriod(10)).toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return new String("Digital Input - Digital Input Counter \"/3200/0/5501\" : " + responseData);
    }
}
