package arm.isg.jp.ws.web;

import com.arm.mbed.cloud.Sdk;
import com.arm.mbed.cloud.sdk.common.ConnectionOptions;
import com.arm.mbed.cloud.sdk.devices.model.Device;
import com.arm.mbed.cloud.sdk.devices.model.DeviceListOptions;
import com.arm.mbed.cloud.sdk.devices.model.DeviceState;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.MediaType;

import java.util.List;
import java.util.ArrayList;

@RestController
public class SimpleWebApp4PDMController {

    @RequestMapping("api/devices/registered")
    public List<Device> showRegisteredDevices(){

        List<Device> deviceList = new ArrayList<Device>();

        try {
            Sdk sdk = Sdk.createSdk(ConnectionOptions.newConfiguration());
            sdk.foundation().getDeviceListDao()
                    .list( (new DeviceListOptions()).equalToState(DeviceState.REGISTERED).maxResults(10) )
                    .forEach(device -> deviceList.add(device));
        } catch (Exception ex){
            ex.printStackTrace();
        }

        return deviceList;
    }

    @RequestMapping(value = "/api/devices/deregistered" , method = RequestMethod.GET , produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Device> listDeregistered(){

        List<Device> deviceList = new ArrayList<Device>();

        try {
            Sdk sdk = Sdk.createSdk(ConnectionOptions.newConfiguration());
            sdk.foundation().getDeviceListDao()
                    .list( (new DeviceListOptions()).equalToState(DeviceState.DEREGISTERED).maxResults(10) )
                    .forEach(device -> deviceList.add(device));
        } catch (Exception ex){
            ex.printStackTrace();
        }

        return deviceList;
    }


    @RequestMapping(value = "/api/devices/all")
    public List<Device> index(){

        List<Device> deviceList = new ArrayList<Device>();

        try {
            Sdk sdk = Sdk.createSdk(ConnectionOptions.newConfiguration());
            sdk.foundation().getDeviceListDao().list( (new DeviceListOptions()).maxResults(10)).forEach(device -> deviceList.add(device) );
        } catch (Exception ex){
            ex.printStackTrace();
        }

        return deviceList;

    }
}
